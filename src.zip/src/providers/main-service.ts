export class MainService {

  public static baseUrl : string = "http://188.226.135.249/api/";
  public static ip : string = "http://188.226.135.249/";
  public static  lang : string = 'ar';
  public static payPalEnvironmentSandbox = 'AQVCB0GR1LZ6TxG_kRLUzCch-fUxwyav0xoK3AgJxJEpVbufN2eCy4XnlqcdMVqiMWsvPePNVCI4-Dc1';
  public static payPalEnvironmentProduction = '';

}
